import sqlite3
from datetime import datetime

db_path='../db.sqlite3'

def check_if_user_exists(users_id: str):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    sending_data = [0, 0]

    try:
        cursor.execute(f'SELECT * FROM main_botuser WHERE user_id = "{users_id}"')
        result = cursor.fetchone()

        if result is not None:
            sending_data[0] = 1
            cursor.execute(f'SELECT if_admin FROM main_botuser WHERE user_id = "{users_id}"')
            result1 = cursor.fetchone()
            sending_data[1] = 1 if result1 is not None else 0

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")

    finally:
        cursor.close()
        conn.close()

    return sending_data

def get_bot_user_id(user_id: str):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        cursor.execute(f'SELECT id FROM main_botuser WHERE user_id = "{user_id}"')
        result = cursor.fetchone()
        bot_user_id = result[0]

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")

    finally:
        cursor.close()
        conn.close()
    return bot_user_id
import sqlite3
from datetime import datetime

def create_topic(topic_name, topic_owner_id):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        created_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        cursor.execute(f'''
            INSERT INTO main_topics (topic_name, topic_owner_id, created_time)
            VALUES ('{topic_name}', {topic_owner_id}, '{created_time}')
        ''')

        conn.commit()

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        return None

    finally:
        cursor.close()
        conn.close()


def get_user_questions(user_id):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        query = f'''
            SELECT 
                aq.id AS question_id,
                aq.question,
                aq.created_date,
                aq.is_faq,
                aq.is_answered,
                tq.topic_name AS question_topic
            FROM main_allquestions AS aq
            LEFT JOIN main_topics AS tq ON aq.question_topic_id = tq.id
            WHERE aq.question_owner_id = (SELECT id FROM main_botuser WHERE user_id = '{user_id}');
        '''

        cursor.execute(query)
        user_questions = cursor.fetchall()

        return user_questions

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")

    finally:
        cursor.close()
        conn.close()




def get_questions_by_topic(topic_id, is_faq_filter:bool):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        if is_faq_filter:
            query = f'''
                SELECT 
                id,
                question,
                created_date,
                is_faq,
                is_answered
                FROM main_allquestions
                WHERE question_topic_id = {topic_id};
            '''
        else:
            query = f'''
                SELECT 
                id,
                question,
                created_date,
                is_faq,
                is_answered
                FROM main_allquestions
                WHERE question_topic_id = {topic_id} AND is_faq = 1;
            '''

        cursor.execute(query)
        questions = cursor.fetchall()
    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
    finally:
        cursor.close()
        conn.close()

    return questions

def get_question_by_id(question_id):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        query = f'''
            SELECT
                aq.*,
                bu.username AS owner_username,
                bu.user_id AS owner_user_id,
                bu.user_phone_number AS owner_user_phone_number,
                bu.joined_date AS owner_joined_date,
                bu.if_admin AS owner_if_admin,
                tq.topic_name AS question_topic_name,
                tq.created_time AS question_topic_created_time,
                ans.answer AS answer_text,
                ans.answer_owner_id AS answer_owner_id,
                ans.answered_date AS answer_date,
                ans_owner.username AS answer_owner_username,
                ans_owner.user_id AS answer_owner_user_id,
                ans_owner.user_phone_number AS answer_owner_user_phone_number,
                ans_owner.joined_date AS answer_owner_joined_date,
                ans_owner.if_admin AS answer_owner_if_admin
            FROM
                main_allquestions AS aq
            LEFT JOIN
                main_botuser AS bu ON aq.question_owner_id = bu.id
            LEFT JOIN
                main_topics AS tq ON aq.question_topic_id = tq.id
            LEFT JOIN
                main_answers AS ans ON aq.id = ans.answered_question_id
            LEFT JOIN
                main_botuser AS ans_owner ON ans.answer_owner_id = ans_owner.id
            WHERE
                aq.id = {question_id};
        '''

        cursor.execute(query)
        question_info = cursor.fetchone()

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        question_info = None

    finally:
        cursor.close()
        conn.close()

    return question_info


def mark_question_as_faq(question_id):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        query = f'''
            UPDATE main_allquestions
            SET is_faq = 1
            WHERE id = {question_id};
        '''

        cursor.execute(query)
        conn.commit()

        return True

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_all_topics():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        query = '''
            SELECT 
                id AS topic_id,
                topic_name,
                created_time,
                topic_owner_id
            FROM main_topics;
        '''

        cursor.execute(query)
        all_topics = cursor.fetchall()

        return all_topics

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")

    finally:
        cursor.close()
        conn.close()


def get_faq_questions():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        query = '''
            SELECT 
                aq.id AS question_id,
                aq.question,
                aq.created_date,
                aq.is_answered,
                tq.topic_name AS question_topic
            FROM main_allquestions AS aq
            LEFT JOIN main_topics AS tq ON aq.question_topic_id = tq.id
            WHERE aq.is_faq = 1;
        '''

        cursor.execute(query)
        faq_questions = cursor.fetchall()

        return faq_questions

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")

    finally:
        cursor.close()
        conn.close()



def get_questions_by_answer_status(is_answered:bool):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        query = f'''
            SELECT
                aq.*,
                bu.username AS owner_username,
                bu.user_id AS owner_user_id,
                bu.user_phone_number AS owner_user_phone_number,
                bu.joined_date AS owner_joined_date,
                bu.if_admin AS owner_if_admin,
                tq.topic_name AS question_topic_name,
                tq.created_time AS question_topic_created_time,
                ans.answer AS answer_text,
                ans.answer_owner_id AS answer_owner_id,
                ans.answered_date AS answer_date,
                ans_owner.username AS answer_owner_username,
                ans_owner.user_id AS answer_owner_user_id,
                ans_owner.user_phone_number AS answer_owner_user_phone_number,
                ans_owner.joined_date AS answer_owner_joined_date,
                ans_owner.if_admin AS answer_owner_if_admin
            FROM
                main_allquestions AS aq
            LEFT JOIN
                main_botuser AS bu ON aq.question_owner_id = bu.id
            LEFT JOIN
                main_topics AS tq ON aq.question_topic_id = tq.id
            LEFT JOIN
                main_answers AS ans ON aq.id = ans.answered_question_id
            LEFT JOIN
                main_botuser AS ans_owner ON ans.answer_owner_id = ans_owner.id
            WHERE
                aq.is_answered = {1 if is_answered else 0};
        '''

        cursor.execute(query)
        questions = cursor.fetchall()

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        questions = []

    finally:
        cursor.close()
        conn.close()

    return questions

def edit_question_with_answer(question_id, answer_text, answer_owner_id, is_faq):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        # Update the AllQuestions table
        cursor.execute(f'''
            UPDATE main_allquestions
            SET is_answered = 1, is_faq = {int(is_faq)}
            WHERE id = {question_id}
        ''')

        # Insert the answer into the Answers table
        answered_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute(f'''
            INSERT INTO main_answers (answer, answered_question_id, answer_owner_id, answered_date)
            VALUES ('{answer_text}', {question_id}, {answer_owner_id}, '{answered_date}')
        ''')

        conn.commit()

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")

    finally:
        cursor.close()
        conn.close()
def create_question(username, user_id, question_text, topic_id, is_faq=False,is_answered=False):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        created_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # Current timestamp

        # Assuming user_id corresponds to an existing user in the BotUser table
        query = f'''
            INSERT INTO main_allquestions (question_owner_id, question_topic_id, question, created_date, is_faq, is_answered)
            VALUES (
                (SELECT id FROM main_botuser WHERE user_id = '{user_id}'),
                {topic_id},
                '{question_text}',
                '{created_date}',
                {is_faq},
                {is_answered}
            );
        '''

        cursor.execute(query)
        conn.commit()

        # Optionally, you can retrieve the ID of the newly created question
        new_question_id = cursor.lastrowid

        return new_question_id

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        return None
    finally:
        cursor.close()
        conn.close()


def create_bot_user(username:str, user_id:str, user_phone_number:str, if_admin:bool):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        joined_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # Current timestamp

        query = f'''
            INSERT INTO main_botuser (username, user_id, user_phone_number, joined_date, if_admin)
            VALUES ('{username}', '{user_id}', '{user_phone_number}', '{joined_date}', {if_admin});
        '''

        cursor.execute(query)
        conn.commit()

        # Optionally, you can retrieve the ID of the newly created user
        new_user_id = cursor.lastrowid

        return new_user_id

    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        return None
    finally:
        cursor.close()
        conn.close()