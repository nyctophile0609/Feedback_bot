import logging
import asyncio
from contextlib import suppress
from aiogram.exceptions import TelegramBadRequest
from aiogram import Bot, Dispatcher, types,F
from aiogram.filters.command import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder


from aconfigreader import config


def get_keyboard():
    buttons=[[types.InlineKeyboardButton(text="ℹ️FAQ-Frequently asked questions",callback_data="show#$#faq")],
            [types.InlineKeyboardButton(text="ℹ️View sections",callback_data="show#$#sections")]
    ]
    keyboard=types.InlineKeyboardMarkup(inline_keyboard=buttons)
    return keyboard
def topic_question_keyboard(question_id):
    buttons=[[types.InlineKeyboardButton(text="Answer it",callback_data=f"answer_{question_id}")],]
    keyboard=types.InlineKeyboardMarkup(inline_keyboard=buttons)
    return keyboard





def number_board(num:int,data_callback:list,checks_it:list,call_string:str):
    builder=InlineKeyboardBuilder()
    for i in range (num):
        if i%2<1:
            builder.row(types.InlineKeyboardButton(text=f'{i+1}',callback_data=f'{call_string}_{i}'))
        
        elif i%2:
            builder.add(types.InlineKeyboardButton(text=f'{i+1}',callback_data=f'{call_string}_{i}'))
   
   
    if checks_it==[1,0]:
        builder.row(types.InlineKeyboardButton(text=f'Back',callback_data=data_callback[0]))
    elif checks_it==[0,1]:
        builder.row(types.InlineKeyboardButton(text=f'Next',callback_data=data_callback[1]))
    elif checks_it==[1,1]:
        builder.row(types.InlineKeyboardButton(text=f'Back',callback_data=data_callback[0]),
        types.InlineKeyboardButton(text='Next',callback_data=data_callback[1]))

    return builder.as_markup()

async def update_questions(message:types.Message,user_actions:int,data_callback:list,questions:list,checks_it:list,call_string:str):
    with suppress(TelegramBadRequest):
        unfinished=await generate_text(questions,user_actions)
        message_text=unfinished[0]

        await message.edit_text(message_text,reply_markup=number_board(unfinished[1],data_callback,checks_it,call_string))



async def generate_text(questions:list,x:int):
    data=''
    if len(questions)>=x:
        questions=questions[x-10:x]

        for i in range(len(questions)):
            data+=f'{i+1}yyyy.{questions[i][1]}\n'
        return [data,1]
    else:
        questions=questions[x-10:]
        for i in range(len(questions)):
            data+=f'{i+1}.{questions[i][1]}\n'
        return [data,len(questions)]
    

def checks_if(pagenumber:int,questions):
    value=[]
    if pagenumber==10 and len(questions)>10:
        value=[0,1]
    elif 10<len(questions)<=pagenumber:
        value=[1,0]
    elif len(questions)<10:
        value=[0,0]
    else:
        value=[1,1]
    return value

def show_behind_nums(behind_nums:list,last_digit:int,page_number:int):
    return behind_nums[page_number-(10-last_digit)]