import logging
import asyncio
from aiogram import Bot, Dispatcher, types,F
from aiogram.filters.command import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from aiogram import exceptions

import sqlite3
from datetime import datetime
from aconfigreader import config
from my_functions import *
from database2 import *
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################

logging.basicConfig(level=logging.INFO)
bot=Bot(config.bot_token.get_secret_value(), parse_mode='HTML')
dp=Dispatcher()
user_actions={}
user_actions['new_question']=0
unasnwered_questions=get_questions_by_answer_status(False)
asnwered_questions=get_questions_by_answer_status(True)
topics=get_all_topics()
faq_questions=get_faq_questions()



###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
@dp.message(Command('start'))
async def cmd_start(message:types.Message):
    checked_user_existence=check_if_user_exists(message.from_user.id)
    if checked_user_existence[1]==1:
        user_actions['users_id'] = str(message.from_user.id)
        user_actions['username']=str(message.from_user.username)
        user_actions['user_status']=[False,True][checked_user_existence[1]==1]
        builder=InlineKeyboardBuilder()
        builder.row(types.InlineKeyboardButton(
            text="View topics", callback_data="view_topics"))
        builder.row(types.InlineKeyboardButton(
            text="View FAQ questions", callback_data="view_faq_questions"))
        builder.row(types.InlineKeyboardButton(
            text="View answered questions", callback_data="view_answered_questions"))
        builder.row(types.InlineKeyboardButton(
            text="View unanswered questions", callback_data="view_unanswered_questions"))
        builder.row(types.InlineKeyboardButton(
            text="Add new topic", callback_data="add_new_topic"))
        await message.reply(f'Hi, {message.from_user.full_name}')
        await message.reply('Choose one:', reply_markup=builder.as_markup()) 
    elif checked_user_existence[0]==1:
        user_actions['users_id'] = str(message.from_user.id)
        user_actions['username']=str(message.from_user.username)
        user_actions['user_status']=[False,True][checked_user_existence[1]==1]
        builder=InlineKeyboardBuilder()
        builder.row(types.InlineKeyboardButton(
            text="View topics", callback_data="view_topics"))
        builder.row(types.InlineKeyboardButton(
            text="View FAQ questions", callback_data="view_faq_questions"))
        builder.row(types.InlineKeyboardButton(
            text="View my questions", callback_data="view_my_questions"))
        builder.row(types.InlineKeyboardButton(
            text="Ask question", callback_data="create_new_question"))

        await message.reply(f'Hi, {message.from_user.full_name}\nChoose on action to continue:',
                            reply_markup=builder.as_markup())

    else:
        builder=ReplyKeyboardBuilder()
        builder.row(types.KeyboardButton(text="Share contact", request_contact=True))
        await message.reply(f'Hi there, {message.from_user.full_name}!',reply_markup=builder.as_markup(resize_keyboard=True))

    


###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
"""This code shows all the topics  to the user"""

@dp.callback_query(F.data=="view_topics")
async def cmd_do_users_action3(callback:types.callback_query):
    user_actions['topic_page_number']=10
    unfinished=await generate_text(topics,user_actions['topic_page_number'])
    checks_it=checks_if(user_actions['topic_page_number'],topics)
    await callback.message.answer(unfinished[0],
        reply_markup=number_board(unfinished[1],['topic_page_back','topic_page_next'],checks_it,'topic_number'))
    await callback.answer()



"""This code controls pagination of topics #user"""

@dp.callback_query(F.data.startswith('topic_page_'))
async def cmd_next_page(callback:types.callback_query):
    user_actions['topic_page_number']+=10 if callback.data=='topic_page_next' else -10
    checks_it=checks_if(user_actions['topic_page_number'],topics)
    await update_questions(callback.message,user_actions['topic_page_number'],
            ['topic_page_back','topic_page_next'],topics,checks_it,'topic_number')
    await callback.answer()



"""This code shows topic questions #user"""

@dp.callback_query(F.data.startswith('topic_number_'))
async def cmd_show_users_questions(callback:types.callback_query):
    qw=callback.data[-1]
    last_digit=int(qw)
    try:
        topic_id=show_behind_nums(topics,last_digit,user_actions['topic_page_number'])[0]
        topic_questions=get_questions_by_topic(topic_id,user_actions['user_status'])
        user_actions["topic_id"]=topic_id
        user_actions['topic_questions_page']=10
        checks_it=checks_if(user_actions['topic_questions_page'],topic_questions)
        unfinished=await generate_text(topic_questions,user_actions['topic_questions_page'])
        await callback.message.answer(unfinished[0],reply_markup=number_board(unfinished[1],
            ['topic_questions_back','topic_questions_next'],checks_it,'topic_question_number'))

        await callback.answer()
    except exceptions.TelegramBadRequest as e: 
        await callback.answer('There is no questions you can see...')



"""This code controls pagination of topics questions page #user"""

@dp.callback_query(F.data.startswith('topic_questions_'))
async def cmd_next_page(callback:types.callback_query):
    topic_questions=get_questions_by_topic(user_actions['topic_id'],user_actions['user_status'])
    user_actions['topic_questions_page']+=10 if callback.data=='topic_questions_next' else -10
    checks_it=checks_if(user_actions['topic_questions_page'],topic_questions)
    await update_questions(callback.message,user_actions['topic_questions_page'],['topic_question_back','topic_question_next'],
                           topic_questions,checks_it,'topic_question_number')
    await callback.answer()



"""THis code shows topic question with detail"""

@dp.callback_query(F.data.startswith('topic_question_number_'))
async def cmd_show_topic_question(callback:types.callback_query):
    qw=callback.data[-1]
    last_digit=int(qw)
    try:
        topic_questions=get_questions_by_topic(user_actions['topic_id'],user_actions['user_status'])
        question_id=show_behind_nums(topic_questions,last_digit,user_actions['topic_questions_page'])[0]
        question_info=get_question_by_id(question_id)
        print(question_info)
    
        if user_actions['user_status']:
            await callback.message.answer(f'''Asked by: @{question_info[7]}
    Answered by {question_info[17]}
    User phone number: {question_info[9]}
    Admin phone number: {question_info[19]}
    Asked date: {question_info[2]}
    Answered date: {question_info[16]}
    Question topic: {question_info[12]}\n
    Question: {question_info[1]}\n
    Answer: {question_info[14]}\n
    ''',reply_markup=topic_question_keyboard(question_info[0]))
        else:
            await callback.message.answer(f'''Answered by {question_info[17]}
    Admin phone number: {question_info[19]}
    Asked date: {question_info[2]}
    Answered date: {question_info[16]}
    Question topic: {question_info[12]}\n
    Question: {question_info[1]}\n
    Answer: {question_info[14]}\n
    ''')
    except exceptions.TelegramBadRequest as e: 
        await callback.answer('There is no questions you can see...')

    await callback.answer()
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
##############################################################################################################
"""This code shows faq questions to the user"""

@dp.callback_query(F.data=="view_faq_questions")
async def cmd_do_users_action2(callback:types.callback_query):
    user_actions['faq_questions_page_number']=10
    unfinished=await generate_text(faq_questions,user_actions['faq_questions_page_number'])
    checks_it=checks_if(user_actions['faq_questions_page_number'],faq_questions)
    await callback.message.answer(unfinished[0],
        reply_markup=number_board(unfinished[1],['faq_questions_page_back','faq_questions_page_next'],checks_it,'faq_question_number'))
    await callback.answer()



"""This code controls pagination of faq qustions #user """

@dp.callback_query(F.data.startswith('faq_questions_page_'))
async def cmd_next_page(callback:types.callback_query):
    user_actions['faq_questions_page_number']+=10 if callback.data=='faq_questions_page_next' else -10
    checks_it=checks_if(user_actions['faq_questions_page_number'],faq_questions)
    await update_questions(callback.message,user_actions['faq_questions_page_number'],
            ['faq_questions_page_back','faq_questions_page_next'],faq_questions,checks_it,'faq_question_number')
    await callback.answer()



"""This code shows faq question with details"""

@dp.callback_query(F.data.startswith('faq_question_number_'))
async def cmd_users_faq_questions(callback:types.callback_query):
    qw=callback.data[-1]
    last_digit=int(qw)
    question_id=show_behind_nums(faq_questions,last_digit,user_actions['faq_questions_page_number'])[0]
    question_info=get_question_by_id(question_id)
    if user_actions['user_status']:
            await callback.message.answer(f'''Asked by: @{question_info[7]}
    Answered by @{question_info[17]}
    User phone number: {question_info[9]}
    Admin phone number: {question_info[19]}
    Asked date: {question_info[2]}
    Answered date: {question_info[16]}
    Question topic: {question_info[12]}\n
    Question: {question_info[1]}\n
    Answer: {question_info[14]}\n
    ''')


    else:
        await callback.message.answer(f'''Answered by {question_info[17]}
    Admin phone number: {question_info[19]}
    Asked date: {question_info[2]}
    Answered date: {question_info[16]}
    Question topic: {question_info[12]}

    Question: {question_info[1]}

    Answer: {question_info[14]}

    ''')
    await callback.answer()
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
"""This code shows answered questions to the admin """

@dp.callback_query(F.data=='view_answered_questions')
async def cmd_questions(callback:types.callback_query):
    user_actions['answered_question_page_num']=10
    unfinished=await generate_text(asnwered_questions,user_actions['answered_question_page_num'])
    checks_it=checks_if(user_actions['answered_question_page_num'],asnwered_questions)
    message_text=unfinished[0]
    await callback.message.reply(message_text, 
                reply_markup=number_board(unfinished[1],['answered_questions_back','answered_questions_next'],
                                          checks_it,"answered_question_number"))
    await callback.answer()



"""This code controls the pagination of answered questions to the admin """

@dp.callback_query(F.data.startswith('adpage#'))
async def cmd_next_page(callback:types.callback_query):
    user_actions['answered_question_page_num']+=10 if callback.data=='adpage#next' else -10
    checks_it=checks_if(user_actions['answered_question_page_num'],asnwered_questions)
    await update_questions(callback.message,user_actions['answered_question_page_num'],
    ['answered_questions_back','answered_questions_next'],asnwered_questions,checks_it,"answered_question_number")
    await callback.answer()



"""This code shows answered question with details to the admin """

@dp.callback_query(F.data.startswith("answered_question_number"))
async def cmd_show_all_questions(callback:types.callback_query):
    qw=callback.data[-1]
    last_digit=int(qw)
    question_id=show_behind_nums(asnwered_questions,last_digit,user_actions['answered_question_page_num'])[0]
    question_info=get_question_by_id(question_id)
    builder=InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text='Add to FAQ', callback_data=f"gotta_add_faq#{question_id}"))
    print(question_info)
    text=f'''Asked by: @{question_info[7]}
Answered by {question_info[17]}
User phone number: {question_info[9]}
Admin phone number: {question_info[19]}
Asked date: {question_info[2]}
Answered date: {question_info[16]}
Question topic: {question_info[12]}

Question: {question_info[1]}

Answer: {question_info[14]}

'''
    if question_info[10]==0:
        await callback.message.answer(text,reply_markup=builder.as_markup())
    
    else:
        await callback.message.answer(text)
    await callback.answer()



"""this code adds question to faq"""

@dp.callback_query(F.data.startswith('gotta_add_faq#'))
async def cmd_adding_to_faq(callback:types.callback_query):
    question_id=callback.data.split('#')[1]
    mark_question_as_faq(question_id)
    await callback.answer('Complete!')


###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
"""This code shows unanswered questions to the admin """

@dp.callback_query(F.data=='view_unanswered_questions')
async def cmd_questions(callback:types.callback_query):
    user_actions['unasnwered_questions_page_num']=10
    unfinished=await generate_text(unasnwered_questions,user_actions['unasnwered_questions_page_num'])
    checks_it=checks_if(user_actions['unasnwered_questions_page_num'],unasnwered_questions)
    message_text=unfinished[0]
    await callback.message.reply(message_text, reply_markup=number_board(unfinished[1],
        ['unanswered_questions_back','unanswered_questions_next'],checks_it,"unanswered_question_number"))
    await callback.answer()



"""This code controls the pagination of unanswered questions to the admin """

@dp.callback_query(F.data.startswith('uadpage#'))
async def cmd_next_page(callback:types.callback_query):
    user_actions["unasnwered_questions_page_num"]+=10 if callback.data=='uadpage#next' else -10
    checks_it=checks_if(user_actions["unasnwered_questions_page_num"],unasnwered_questions)
    await update_questions(callback.message,user_actions['unasnwered_questions_page_num'],
        ['unanswered_questions_back','unanswered_questions_next'],unasnwered_questions,checks_it,'unanswered_question_number')
    await callback.answer()



"""This code shows unanswered question with details to the admin """

@dp.callback_query(F.data.startswith('unanswered_question_number_'))
async def cmd_show_all_questions(callback:types.callback_query):
    qw=callback.data[-1]
    last_digit=int(qw)
    question_id=show_behind_nums(unasnwered_questions,last_digit,user_actions['unasnwered_questions_page_num'])[0]
    question_info=get_question_by_id(question_id)
    builder=InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text='Answer it', callback_data=f'unanswered_question_#{question_info[0]}'))
    await callback.message.answer(f'''Asked by: @{question_info[7]}
User phone number: {9}
Asked date: {question_info[2]}
Question topic: {question_info[12]}

Question: {question_info[1]}
''',reply_markup=builder.as_markup())
    await callback.answer()
user_actions['new_answer_id']=[0,0,]
@dp.callback_query(F.data.startswith('unanswered_question_#'))
async def attaching_answer(callback:types.callback_query):
    user_actions['new_answer_id'][0]=callback.data.split('#')[1]
    await callback.message.answer('''Send your answer:\nNote:answer cannot contain media files!''')
    await callback.answer()

        
@dp.callback_query(F.data.startswith('is_faq_or_'))
async def attached_answer(callback:types.callback_query):
    user_id=get_bot_user_id(user_actions['users_id'])
    answer_info=user_actions['new_answer_id']
    is_faq=True if 'yes' in callback.data else False
    edit_question_with_answer(answer_info[0],answer_info[1],user_id,is_faq)
    user_actions['new_answer_id']=[0,0,]
    await callback.answer('Your answer is saved!')
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
user_actions['new_topic']=0
@dp.callback_query(F.data=='add_new_topic')
async def create_new_topic(callback:types.callback_query):
    user_actions['new_topic']=1
    await callback.message.answer('Enter a name for new topic')
    await callback.answer()

###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
"""This code shows users questions to the user """

@dp.callback_query(F.data=="view_my_questions")
async def cmd_do_users_action1(callback:types.callback_query):
    try:
        user_actions['my_questions_page_num']=10
        users_questions=get_user_questions(user_actions['users_id'])
        unfinished=await generate_text(users_questions,user_actions['my_questions_page_num'])
        checks_it=checks_if(user_actions['my_questions_page_num'],users_questions)
        await callback.message.answer(unfinished[0],
            reply_markup=number_board(unfinished[1],['my_questions_back','my_questions_next'],checks_it,'my_question_number'))
        await callback.answer()
    except exceptions.TelegramBadRequest as e: 
        await callback.answer('You have no questions yet!')


"""This code controls pagination of user's questions"""

@dp.callback_query(F.data.startswith('my_questions_'))
async def cmd_next_page(callback:types.callback_query):
    users_questions=get_user_questions(user_actions['users_id'])

    user_actions['my_questions_page_num']+=10 if callback.data=='my_questions_next' else -10
    checks_it=checks_if(user_actions['my_questions_page_num'],unasnwered_questions)
    await update_questions(callback.message,user_actions['my_questions_page_num'],
       ['my_questions_back','my_questions_next'],users_questions,checks_it,'my_question_number')
    await callback.answer()


"""This code shows user's question with details"""

@dp.callback_query(F.data.startswith('my_question_number'))
async def cmd_show_my_questions(callback:types.callback_query):
    users_questions=get_user_questions(user_actions['users_id'])
    qw=callback.data[-1]
    last_digit=int(qw)
    question_id=show_behind_nums(users_questions,last_digit,user_actions["my_questions_page_num"])[0]
    question_info=get_question_by_id(question_id)
    print(question_info)
    await callback.message.answer(f'''Answered by {question_info[17]}
Admin phone number: {question_info[19]}
Asked date: {question_info[2]}
Answered date: {question_info[16]}
Question topic: {question_info[12]}

Question: {question_info[1]}

Answer: {question_info[14]}

''')
    await callback.answer()
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################


@dp.callback_query(F.data=='create_new_question')
async def cmd_create_new_question(callback:types.callback_query):
    user_actions['for_question_page_num']=10
    unfinished=await generate_text(topics,user_actions['for_question_page_num'])
    checks_it=checks_if(user_actions['for_question_page_num'],topics)
    await callback.message.answer(f'Please choose a topic for your question:\n{unfinished[0]}',
        reply_markup=number_board(unfinished[1],
                ['for_question_back','for_question_next'],checks_it,'for_question_number'))
    await callback.answer()



"""this code controls pagination of topics: part of code above"""

@dp.callback_query(F.data.startswith('for_questions_'))
async def cmd_next_page(callback:types.callback_query):
    user_actions['for_question_page_num']+=10 if callback.data=='user#$#topicp#next' else -10
    checks_it=checks_if(user_actions['for_question_page_num'],topics)
    await update_questions(callback.message,user_actions['for_question_page_num'],
        ['for_question_back','for_question_next'],topics,checks_it,'for_question_number')
    await callback.answer()




"""this code creates a user's new question 2 """

@dp.callback_query(F.data.startswith('for_question_number_'))
async def cmd_create_new_question2(callback:types.callback_query):
    qw=callback.data[-1]
    last_digit=int(qw)
    topic_id=show_behind_nums(topics,last_digit,user_actions['for_question_page_num'])[0]
    topics_questions=get_questions_by_topic(topic_id,user_actions['user_status'])
    user_actions['new_question_t_id']=topic_id
    user_actions['new_question']=1
    await callback.message.answer("Well done! Now please send me your question...\nquestion cannot contain medias")
    await callback.answer()





@dp.message(F.text)
async def create_new_topic(message:types.Message):
    if user_actions['new_topic']==1:
        user_id=get_bot_user_id(user_actions['users_id'])
        create_topic(message.text,user_id)
        user_actions['new_topic']=0   
        print('hejf')
        await message.reply('Succesfuly created!')
    elif user_actions['new_answer_id'][0]!=0:
        user_actions['new_answer_id'][1]=message.text
        builder=InlineKeyboardBuilder()
        builder.row(types.InlineKeyboardButton(text='Yes',callback_data='is_faq_or_yes'))
        builder.add(types.InlineKeyboardButton(text='No',callback_data='is_faq_or_no'))
        await message.reply('Do you want to add your answer to FAQ answers',
                            reply_markup=builder.as_markup())
    elif user_actions['new_question']==1:
            create_question(user_actions['username'],user_actions['users_id'],message.text,user_actions['new_question_t_id'])
            user_actions['new_question']=0
            builder=InlineKeyboardBuilder()
            builder.row(types.InlineKeyboardButton(
                text="View my questions", callback_data="question#$#viewing#user#"))
            builder.row(types.InlineKeyboardButton(
                text="View FAQ questions", callback_data="question#$#viewing#faq#"))
            builder.row(types.InlineKeyboardButton(
                text="View topics", callback_data="question#$#viewing#topic#"))
            builder.row(types.InlineKeyboardButton(
                text="Ask question", callback_data="question#$#asking#new#"))
            await message.reply('Your question accepted!\nyou can check if your question has been answered by clicking "yes".',
                                reply_markup=builder.as_markup())






@dp.message(F.contact)
async def cmd_register_new_user(message:types.Message):
    user_actions['users_id'] = str(message.from_user.id)
    user_actions['username']=str(message.from_user.username)
    checked_user_existence=check_if_user_exists(message.from_user.id)
    user_actions['user_status']=[False,True][checked_user_existence[1]==1]
    builder=InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(
        text="View topics", callback_data="view_topics"))
    builder.row(types.InlineKeyboardButton(
        text="View FAQ questions", callback_data="view_faq_questions"))
    builder.row(types.InlineKeyboardButton(
        text="View my questions", callback_data="view_my_questions"))
    builder.row(types.InlineKeyboardButton(
        text="Ask question", callback_data="create_new_question"))
    await message.reply('Registration is complete!',reply_markup=types.ReplyKeyboardRemove())
    await message.answer('Choose one action to continue!:',reply_markup=builder.as_markup())


















###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
###############################################################################################################
async def main():
    await dp.start_polling(bot)

if __name__=='__main__':
    asyncio.run(main())