from django.db import models

class BotUser(models.Model):
    username = models.CharField(max_length=150)
    user_id = models.CharField(max_length=30,)
    user_phone_number=models.CharField(max_length=20,blank=True)
    joined_date = models.DateTimeField(auto_now_add=True)
    if_admin = models.BooleanField()


class Topics(models.Model):
    topic_name = models.CharField(max_length=150)
    topic_owner = models.ForeignKey(BotUser, on_delete=models.CASCADE)
    created_time = models.DateTimeField(auto_now_add=True)

class AllQuestions(models.Model):
    question_owner = models.ForeignKey(BotUser, on_delete=models.CASCADE)
    question_topic = models.ForeignKey(Topics, on_delete=models.CASCADE)
    question = models.CharField(max_length=300)
    created_date = models.DateTimeField(auto_now_add=True)
    is_answered = models.BooleanField(default=False)
    is_faq=models.BooleanField(default=False)


class Answers(models.Model):
    answer = models.CharField(max_length=300)
    answered_question=models.ForeignKey(AllQuestions,on_delete=models.CASCADE,)
    answer_owner = models.ForeignKey(BotUser, on_delete=models.CASCADE)
    answered_date = models.DateTimeField(auto_now_add=True)
