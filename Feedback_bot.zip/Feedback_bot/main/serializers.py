from .models import *
from rest_framework import serializers

class BotUserSerializer(serializers.ModelSerializer):
    class Meta:
        model=BotUser
        fields='__all__'

class AnswersSerializer(serializers.ModelSerializer):
    class Meta:
        model=Answers
        fields='__all__'

class TopicsSerializer(serializers.ModelSerializer):
    class Meta:
        model=Topics
        fields='__all__'

class AllQuestionsSerializer(serializers.ModelSerializer):
    class Meta:
        model=AllQuestions
        fields='__all__'