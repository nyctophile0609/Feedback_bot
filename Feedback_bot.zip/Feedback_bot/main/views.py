from rest_framework import viewsets
from .serializers import *
from .models import *

class BotUserViewSet(viewsets.ModelViewSet):
    queryset=BotUser.objects.all()
    serializer_class=BotUserSerializer

class AnswersViewSet(viewsets.ModelViewSet):
    queryset=Answers.objects.all()
    serializer_class=AnswersSerializer

class TopicsViewSet(viewsets.ModelViewSet):
    queryset=Topics.objects.all()
    serializer_class=TopicsSerializer

class AllQuestionsViewSet(viewsets.ModelViewSet):
    queryset=AllQuestions.objects.all()
    serializer_class=AllQuestionsSerializer
